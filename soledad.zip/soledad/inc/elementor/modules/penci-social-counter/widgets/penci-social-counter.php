<?php

namespace PenciSoledadElementor\Modules\PenciSocialCounter\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use PenciSoledadElementor\Base\Base_Widget;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PenciSocialCounter extends Base_Widget {

	public function get_name() {
		return 'penci-social-counter';
	}

	public function get_title() {
		return esc_html__( 'Penci Social Counter', 'soledad' );
	}

	public function get_icon() {
		return 'eicon-share';
	}

	public function get_categories() {
		return [ 'penci-elements' ];
	}

	public function get_keywords() {
		return array( 'social counter' );
	}


	protected function _register_controls() {
		parent::_register_controls();

		$this->start_controls_section(
			'section_general', array(
				'label' => esc_html__( 'General', 'soledad' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'app_id', array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => '<span style="color: red;font-weight: bold;">Note Important</span>: You need to setup data for socials sharing via <strong>Dashboard > Soledad > Social Counter</strong> to make this element work.',
				'content_classes' => 'elementor-descriptor',

			)
		);

		$this->add_control(
			'penci_block_width', array(
				'label'   => __( 'Element Columns', 'soledad' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 1,
				'options' => array(
					'1' => esc_html__( '1 Column', 'soledad' ),
					'2' => esc_html__( '2 Columns', 'soledad' ),
					'3' => esc_html__( '3 Columns', 'soledad' ),
					'4' => esc_html__( '4 Columns', 'soledad' ),
					'5' => esc_html__( '5 Columns', 'soledad' ),
					'6' => esc_html__( '6 Columns', 'soledad' ),
				)
			)
		);

		$this->add_control(
			'social_style', array(
				'label'   => __( 'Choose Style', 'soledad' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 's1',
				'options' => array(
					's1' => esc_html__( 'Style 1', 'soledad' ),
					's2' => esc_html__( 'Style 2', 'soledad' ),
					's3' => esc_html__( 'Style 3', 'soledad' ),
					's4' => esc_html__( 'Style 4', 'soledad' ),
					's5' => esc_html__( 'Style 5', 'soledad' ),
					's6' => esc_html__( 'Style 6', 'soledad' ),
					's7' => esc_html__( 'Style 7', 'soledad' ),
					's8' => esc_html__( 'Style 8', 'soledad' ),
					's9' => esc_html__( 'Style 9', 'soledad' ),
				)
			)
		);

		$pmetas = array(
			'facebook'   => array( 'label' => __( 'Facebook', 'soledad' ), 'default' => 'yes' ),
			'twitter'    => array( 'label' => __( 'Twitter', 'soledad' ), 'default' => 'yes' ),
			'youtube'    => array( 'label' => __( 'Youtube', 'soledad' ), 'default' => 'yes' ),
			'instagram'  => array( 'label' => __( 'Instagram', 'soledad' ), 'default' => 'yes' ),
			'pinterest'  => array( 'label' => __( 'Pinterest', 'soledad' ), 'default' => '' ),
			'flickr'     => array( 'label' => __( 'Flickr', 'soledad' ), 'default' => '' ),
			'vimeo'      => array( 'label' => __( 'Vimeo', 'soledad' ), 'default' => '' ),
			'soundcloud' => array( 'label' => __( 'SoundCloud', 'soledad' ), 'default' => '' ),
			'behance '   => array( 'label' => __( 'Behance', 'soledad' ), 'default' => '' ),
			'vk'         => array( 'label' => __( 'VK', 'soledad' ), 'default' => '' ),
			'twitch'     => array( 'label' => __( 'Twitch', 'soledad' ), 'default' => '' ),
			'rss'        => array( 'label' => __( 'RSS', 'soledad' ), 'default' => '' ),
		);

		foreach ( $pmetas as $key => $pmeta ) {
			$this->add_control( 'social_' . $key, array(
					'label'       => $pmeta['label'],
					'type'        => Controls_Manager::SWITCHER,
					'label_on'    => __( 'Show', 'soledad' ),
					'label_off'   => __( 'Hide', 'soledad' ),
					'default'     => $pmeta['default'],
					'separator'   => '',
					'description' => __( 'Setup ' . esc_attr( $pmeta['label'] ) . ' counter data <a target="_blank" href="' . esc_url( admin_url( 'admin.php?page=penci_social_counter_settings#tab-' . $key ) ) . '">here</a>.' ),
				)
			);
		}

		$this->end_controls_section();
		$this->register_block_title_section_controls();
		$this->start_controls_section(
			'section_content_style',
			array(
				'label' => __( 'Social Item Settings', 'soledad' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'counter_item_icon_size',
			[
				'label'      => __( 'Icon Size', 'soledad' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item span i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), array(
				'name'     => 'counter_item_typo_number',
				'label'    => __( 'Number Typography', 'soledad' ),
				'selector' => '{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item span .penci-social-number',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), array(
				'name'     => 'counter_item_typo_infotext',
				'label'    => __( 'Info Text Typography', 'soledad' ),
				'selector' => '{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item span .penci-social-info-text',
			)
		);

		$this->add_control(
			'counter_item_outer_padding',
			[
				'label'      => __( 'Item Outer Padding', 'soledad' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'counter_item_inner_padding',
			[
				'label'      => __( 'Item Inner Padding', 'soledad' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'counter_item_spacing',
			[
				'label'      => __( 'Item Spacing', 'soledad' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'counter_item_border_color', array(
				'label'     => __( 'Item Border Color', 'soledad' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item a' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		foreach ( $pmetas as $key => $pmeta ) {
			$this->start_controls_section(
				'section_counter_style_' . $key,
				array(
					'label' => $pmeta['label'] . ' ' . __( 'Colors Customize', 'soledad' ),
					'tab'   => Controls_Manager::TAB_STYLE,
				)
			);
			$this->add_control(
				'counter_' . $key . '_bg_color', array(
					'label'     => __( 'Background Color', 'soledad' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => array(
						'{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item.penci-social-' . $key . ' a' => 'background-color: {{VALUE}} !important;',
					),
				)
			);
			$this->add_control(
				'counter_' . $key . '_border_color', array(
					'label'     => __( 'Border Color', 'soledad' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => array(
						'{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item.penci-social-' . $key . ' a' => 'border-color: {{VALUE}} !important;',
					),
				)
			);
			$this->add_control(
				'counter_' . $key . '_icon_color', array(
					'label'     => __( 'Icon Color', 'soledad' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => array(
						'{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item.penci-social-' . $key . ' span i' => 'color: {{VALUE}} !important;',
					),
				)
			);
			$this->add_control(
				'counter_' . $key . '_counter_color', array(
					'label'     => __( 'Counter Color', 'soledad' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => array(
						'{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item.penci-social-' . $key . ' span .penci-social-number' => 'color: {{VALUE}} !important;',
					),
				)
			);
			$this->add_control(
				'counter_' . $key . '_infotext_color', array(
					'label'     => __( 'Information Text Color', 'soledad' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => array(
						'{{WRAPPER}} .penci-socialCT-wrap .penci-socialCT-item.penci-social-' . $key . ' span .penci-social-info-text' => 'color: {{VALUE}} !important;',
					),
				)
			);
			$this->end_controls_section();
		}

		$this->register_block_title_style_section_controls();

	}

	protected function render() {
		$settings = $this->get_settings();

		$css_class    = 'penci-block-vc penci-social-counter';
		$social_style = isset( $settings['social_style'] ) && $settings['social_style'] ? $settings['social_style'] : 's1';
		$this->add_render_attribute(
			[
				'wrapper' => [
					'class' => [
						'penci-socialCT-wrap',
						'columns-' . esc_attr( $settings['penci_block_width'] ),
						'penci-socialCT-' . esc_attr( $social_style ),
						's8' == $social_style ? 'penci-social-textcolored' : 'penci-normal-textcolored',
					],
				],
			]
		);
		?>
        <div class="<?php echo esc_attr( $css_class ); ?>">
			<?php $this->markup_block_title( $settings, $this ); ?>
            <div class="penci-block_content">
				<?php
				$socials = array(
					'facebook',
					'twitter',
					'youtube',
					'instagram',
					'pinterest',
					'flickr',
					'vimeo',
					'soundcloud',
					'behance ',
					'vk',
					'twitch',
					'rss',
				);

				$error = array();

				$has_data = false;

				echo '<div ' . $this->get_render_attribute_string( 'wrapper' ) . '>';

				foreach ( $socials as $social ) {


					if ( empty( $settings[ 'social_' . $social ] ) ) {
						continue;
					}

					$social_info = \PENCI_FW_Social_Counter::get_social_counter( $social );

					$social_info_name = isset( $social_info['name'] ) ? $social_info['name'] : '';

					if ( ! $social_info || ! $social_info_name ) {
						continue;
					}

					$has_data = true;

					$target = 'target="_blank"';
					if ( ! get_theme_mod( 'penci_dis_noopener' ) ) {
						$target .= ' rel=noopener"';
					}

					$count = \PENCI_FW_Social_Counter::format_followers( $social_info['count'] );
					$count = $count ? $count : 99.999;
					?>
                    <div class="penci-socialCT-item penci-social-<?php echo $social . ( ! $social_info['count'] ? ' penci-socialCT-empty' : '' ); ?>">
                        <a class="penci-social-content"
                           href="<?php echo esc_url( $social_info['url'] ); ?>" <?php echo $target; ?>>
						<span>
						<?php
						if ( 's1' == $social_style ) {
							echo $social_info['icon'];
							echo '<span class="penci-social-name">' . $social_info['title'] . '</span>';
							echo '<span class="penci-social-button">';

							if ( $count ) {
								echo '<span>' . $count . '</span>';
							}

							echo $social_info['text_btn'];
							echo '</span>';
						} elseif ( 's2' == $social_style ) {
							echo $social_info['icon'];
							echo '<span class="penci-social-name">' . $social_info['title'] . '</span>';
						} elseif ( 's3' == $social_style || 's5' == $social_style || 's6' == $social_style ) {
							echo $social_info['icon'];
						} else {
							echo $social_info['icon'];
							if ( $count ) {
								echo '<span class="penci-social-number">' . $count . '</span>';
							}
							if ( isset( $social_info['text_below'] ) && $social_info['text_below'] ) {
								echo '<span class="penci-social-info-text">' . $social_info['text_below'] . '</span>';
							}
						}
						?>
						</span>
                        </a>
						<?php
						if ( 's6' == $social_style && isset( $social_info['count'] ) ) {
							echo '<span class="penci-social-number">' . $count . '</span>';
							if ( isset( $social_info['text'] ) ) {
								echo '<span class="penci-social-info-text">' . $social_info['text'] . '</span>';
							}
						}
						?>
                    </div>
					<?php

					if ( ! empty( $social_info['error'] ) ) {
						$error[] = $social_info['error'];
					}
				}

				echo '</div>';

				if ( ! $has_data ) {
					$error[] = esc_html__( 'Please go to Dashboad > Soledad > Social Counter, press Social Counter tab then insert social information you want show', 'soledad' );
				}
				?>
            </div>
        </div>
		<?php
	}
}
